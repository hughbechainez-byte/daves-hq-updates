# BroBro Boot Overlay

BroBro Boot Overlay is a Magisk module that starts a small Java runtime renderer with `app_process64` during boot. The renderer creates a SurfaceControl layer, draws an opaque Dave OS boot surface, and exits when Android's bootanimation service stops, with `sys.boot_completed` as a fallback.

## What It Does

- launches `com.brobro.bootoverlay.NativeBootMain` directly from Magisk
- reads `/data/adb/modules/brobro_boot_overlay/config`
- reads `/data/adb/modules/brobro_boot_overlay/logo.png`
- draws a full-screen animated gradient, LiveBoot-style logcat feed, PNG logo, and estimated-time progress bar
- keeps native boot text rendering disabled
- includes a GUI APK for editing and applying module config and logo

## What It Does Not Do

- it does not patch `framework-res.apk`
- it does not replace `bootanimation.zip`
- it does not touch system partitions
- it does not install automatically
- it does not reboot automatically

## GrapheneOS Timing

GrapheneOS may still show briefly before Magisk reaches `post-fs-data.sh` or `service.sh`. This module starts as early as Magisk can safely launch it, but it cannot cover pre-Magisk boot stages without framework or system image patching.

The v0.9 renderer starts from Magisk `post-fs-data` with no configured delay and attempts SurfaceControl before initializing an Android system context. It watches `init.svc.bootanim` and removes the overlay when Android's bootanimation service stops. `sys.boot_completed` remains a fallback if the bootanimation service state is unavailable.

The earliest GrapheneOS/bootloader logo pixels can appear before Magisk is able to run modules. Matching those pre-Magisk pixels exactly would require OS image or framework integration, which this module intentionally avoids.

## Settings GUI

Install `brobro_boot_overlay.apk` manually if you want the GUI. The GUI separates preview/app settings from boot module settings.

Use:

- `Generate Logo PNG` to rasterize logo text inside the normal app process
- `Import PNG Logo` to choose a custom PNG from storage
- `Preview Current Boot Config` to preview the current app-side config
- `Reload from Module` to read `/data/adb/modules/brobro_boot_overlay/config` and `logo.png` through `su`
- `Apply to Boot Module` to write and verify both module files through `su`

The boot renderer never uses native `drawText`; it only decodes and draws `logo.png`.
The scrolling boot text is drawn with simple geometric pixel glyphs, so it avoids Android font/typeface initialization during early boot.

## v1.0.0 Customization

The default v1.0.0 look is Dave OS: an opaque teal/yellow/green animated gradient, full-screen scrolling logcat behind the logo, a center `logo.png`, and a lower progress bar. If logcat is unavailable during early boot, the renderer falls back to the configured pseudo lines.

LiveBoot text blur is disabled and old `liveboot_text_blur` values are ignored. Every frame replaces the complete SurfaceControl canvas with an opaque background before drawing text, logo, and progress to prevent retained-frame smearing.

The LiveBoot Feed tab supports instant, word-by-word, and character-by-character reveal modes. Reveal timing is calculated from elapsed render time and never pauses the boot render loop.

Logcat lines now scroll once instead of looping back to the beginning. Exact duplicate captured lines are removed. Optional custom final lines can be enabled in the LiveBoot Feed tab and are appended during the last 3, 5, or 8 estimated seconds.

When this module ZIP updates an existing installation, `config` and `logo.png` are preserved from `/data/adb/modules/brobro_boot_overlay`. The app also keeps its preferences across APK upgrades. Settings change to defaults only after selecting `Return to Default Settings`; use `Apply to Boot Module` to make those defaults active during boot.

The Gradient Studio provides:

- linear, radial, sweep, repeating-band, radial-band, checker, diamond, and rings patterns
- drift, pulse, rotate, wave, orbit, shimmer, glide, ripple, breathe, and static animation modes
- continuous 20–300% speed control with the calculated cycle time
- pattern angle, scale, center, color-stop, motion, and loop-shape controls
- global brightness, saturation, contrast, gamma, vibrance, hue shift, and reverse controls
- three editable gradient colors

The color picker uses a touch-driven saturation/lightness plane with separate hue and alpha controls.
The preview stays visible above every tab so you can see changes without jumping back to a dedicated page.
The Apply page also includes five boot profile slots so you can save, load, and apply alternate configurations without rebuilding from scratch each time.

Boot, in-app preview, and live wallpaper use the same gradient renderer. The preview box reflects the boot coordinate space, so placement and proportions match the boot renderer.

The generated Dave OS PNG also has an independent logo text background color with alpha support.

The GUI can edit:

- gradient pattern, animation, colors, continuous speed, angle, and scale
- logo text, PNG import, TTF/OTF import, and generated PNG output
- foreground CRT/VHS-style logo/text effects
- whole-screen effects like scanlines, flicker, and vignette
- animated color-cycle background mode
- wallpaper logo visibility, size, position, and alpha
- LiveBoot-style text color, opacity, reveal mode, reveal speed, scroll speed, size, density, and final custom lines
- progress duration, max duration, post-boot hold, position, width, height, and color
- the animated gradient can also be previewed and selected as an Android live wallpaper
- the app can check a GitHub Pages manifest for updates, install a new APK, and download the module ZIP when a module flash is needed
- on launch, the app checks `updates.json` and prompts before installing if a newer APK or module is available
- module updates are applied through root with Magisk's module installer, so you do not need to open Magisk manually for each release

`Apply to Boot Module` writes:

- `/data/adb/modules/brobro_boot_overlay/config`
- `/data/adb/modules/brobro_boot_overlay/logo.png`

`Diagnostics` shows module paths, APK/module versions, the current config, logo size, renderer status, and the last native boot log excerpt.

## Build And Rollback

- Build the APK and module ZIP with `bash build_overlay_apk.sh`
- Install the ZIP manually from Magisk if you choose to use it
- Roll back by disabling or removing the module from Magisk
