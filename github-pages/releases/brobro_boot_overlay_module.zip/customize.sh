#!/system/bin/sh

ui_print "- BroBro Boot Overlay"
ui_print "- This module wires a boot-time runtime overlay launcher"
ui_print "- It does not patch framework-res.apk or replace bootanimation.zip"

for required in module.prop config logo.png loader.sh service.sh post-fs-data.sh overlay.apk; do
	if [ ! -f "$MODPATH/$required" ]; then
		abort "missing required file: $required"
	fi
done

INSTALLED_MODPATH="/data/adb/modules/brobro_boot_overlay"
if [ "$MODPATH" != "$INSTALLED_MODPATH" ] && [ -d "$INSTALLED_MODPATH" ]; then
	for preserved in config logo.png; do
		if [ -f "$INSTALLED_MODPATH/$preserved" ]; then
			cp -f "$INSTALLED_MODPATH/$preserved" "$MODPATH/$preserved" \
				|| abort "could not preserve existing $preserved"
			ui_print "- Preserved existing $preserved"
		fi
	done
fi

ui_print "- Setting file permissions"
set_perm "$MODPATH/module.prop" 0 0 0644
set_perm "$MODPATH/config" 0 0 0644
set_perm "$MODPATH/logo.png" 0 0 0644
set_perm "$MODPATH/loader.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/overlay.apk" 0 0 0644
if [ -f "$MODPATH/README_LIVEBOOT_OVERLAY.md" ]; then
	set_perm "$MODPATH/README_LIVEBOOT_OVERLAY.md" 0 0 0644
fi

ui_print "- Overlay payload installed"
ui_print "- Install the same APK manually if you want the settings GUI"
