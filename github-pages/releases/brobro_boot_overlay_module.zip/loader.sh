#!/system/bin/sh

LOG_FILE="/data/local/tmp/brobro_native_boot.log"
LOCK_DIR="/dev/brobro_boot_overlay.lock"
APK_PATH="/data/adb/modules/brobro_boot_overlay/overlay.apk"
ENTRYPOINT="com.brobro.bootoverlay.NativeBootMain"

log() {
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo time-unknown)" "$*" >> "$LOG_FILE" 2>/dev/null || true
}

run_step() {
  label="$1"
  cmd="$2"
  log "step=$label cmd=$cmd"
  if sh -c "$cmd" >> "$LOG_FILE" 2>&1; then
    log "step=$label success exit=0"
    return 0
  fi
  code=$?
  log "step=$label failure exit=$code"
  return "$code"
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  log "lock exists; launch already attempted this boot"
  exit 0
fi

log "boot trigger start pid=$$ uid=$(id -u 2>/dev/null || echo unknown)"
log "renderer=native app_process64"
log "bootanim_state_before_launch=$(getprop init.svc.bootanim 2>/dev/null || echo unknown)"
log "uptime_before_launch=$(cat /proc/uptime 2>/dev/null || echo unknown)"

if [ ! -f "$APK_PATH" ]; then
  log "missing apk payload at $APK_PATH"
  exit 1
fi

export CLASSPATH="$APK_PATH"
log "launch command=app_process64 /system/bin $ENTRYPOINT"
exec app_process64 /system/bin "$ENTRYPOINT" >> "$LOG_FILE" 2>&1
