#!/system/bin/sh
# Magisk post-fs-data entrypoint.
# This matches the LiveBoot module pattern by calling the same loader used by service.sh.
MODDIR="${0%/*}"
exec "$MODDIR/loader.sh"

