#!/system/bin/sh
# Magisk service-stage entrypoint.
# Keep this tiny: it simply delegates to loader.sh so the launcher logic stays in one place.
MODDIR="${0%/*}"
exec "$MODDIR/loader.sh"

